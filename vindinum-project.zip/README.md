# Vindinium Server

This is a node server that should execute vindinium bots

It also is a central repository for a bots in an AI class for example

## Screenshots

Index
![](http://cl.ly/image/1r0k3U1b3X20/Image%202015-02-04%20at%209.28.51%20PM.png)

Bots
![](http://cl.ly/image/1f2K0J102m2T/Image%202015-02-04%20at%209.29.47%20PM.png)

Bot Dashboard
![](http://cl.ly/image/1N362L1F2f1z/Image%202015-02-04%20at%209.29.58%20PM.png)

Bot editor
![](http://cl.ly/image/1c3W2v0Q3o0q/Image%202015-02-04%20at%209.30.08%20PM.png)

Results
![](http://cl.ly/image/171X0z053j1j/Image%202015-02-04%20at%209.30.17%20PM.png)

Users
![](http://cl.ly/image/2602012P1i1G/Image%202015-02-04%20at%209.30.28%20PM.png)
